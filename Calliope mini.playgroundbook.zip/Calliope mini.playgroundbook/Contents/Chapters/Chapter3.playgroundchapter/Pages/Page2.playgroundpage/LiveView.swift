import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("3-2", [.Display], [], [])
PlaygroundPage.current.liveView = dashBoardController
