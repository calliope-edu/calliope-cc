//:#localized(key: "cc.calliope.miniplaygroundbook.Inputs.IssuingCommands")

//#-hidden-code
import Foundation
import PlaygroundSupport
//#-end-hidden-code

//#-hidden-code
playgroundPrologue()
//#-end-hidden-code

//#-code-completion(everything, hide)
func onShake() {
    display.show(text: "/*#-editable-code*/<#T##string##String#>/*#-end-editable-code*/")
}

//#-hidden-code
playgroundEpilogue( BookProgramInputShake.assessment )
//#-end-hidden-code
