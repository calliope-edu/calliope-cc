import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("2-5", [.Display], [.Shake], [])
PlaygroundPage.current.liveView = dashBoardController
