import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("4-2", [.Display], [.ButtonA], [])
PlaygroundPage.current.liveView = dashBoardController
