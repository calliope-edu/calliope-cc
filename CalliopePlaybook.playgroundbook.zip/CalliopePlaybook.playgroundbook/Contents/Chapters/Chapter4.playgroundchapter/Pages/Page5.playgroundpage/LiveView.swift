import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("4-5", [.Sound], [], [.Brightness])
PlaygroundPage.current.liveView = dashBoardController
