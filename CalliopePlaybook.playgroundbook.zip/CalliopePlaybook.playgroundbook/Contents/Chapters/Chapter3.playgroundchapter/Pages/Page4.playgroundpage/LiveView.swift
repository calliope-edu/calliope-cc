import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("3-4", [.RGB], [], [])
PlaygroundPage.current.liveView = dashBoardController
