import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("3-7", [.Display], [.Shake], [])
PlaygroundPage.current.liveView = dashBoardController
