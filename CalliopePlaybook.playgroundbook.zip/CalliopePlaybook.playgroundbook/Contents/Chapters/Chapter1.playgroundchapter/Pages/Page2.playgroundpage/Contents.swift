//:#localized(key: "cc.calliope.miniplaygroundbook.Inputs001")

//#-hidden-code
import Foundation
import PlaygroundSupport
//#-end-hidden-code

//#-hidden-code
playgroundPrologue()
//#-end-hidden-code

//#-code-completion(everything, hide)
display.show(number: /*#-editable-code*/<#T##number##UInt#>/*#-end-editable-code*/)

//#-hidden-code
//#-editable-code Tap to write your code
//#-end-editable-code
//#-end-hidden-code

//#-hidden-code
playgroundEpilogue( assessment() )
//#-end-hidden-code
