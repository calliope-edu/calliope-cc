import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("1-6", [.Sound], [], [])
PlaygroundPage.current.liveView = dashBoardController
