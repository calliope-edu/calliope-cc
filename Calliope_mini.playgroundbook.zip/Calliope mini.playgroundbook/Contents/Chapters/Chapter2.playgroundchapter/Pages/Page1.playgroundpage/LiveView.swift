import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("2-1", [.Display], [.ButtonA], [])
PlaygroundPage.current.liveView = dashBoardController
