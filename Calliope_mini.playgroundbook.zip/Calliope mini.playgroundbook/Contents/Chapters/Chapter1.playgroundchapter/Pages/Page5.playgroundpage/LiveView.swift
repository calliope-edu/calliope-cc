import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("1-5", [.RGB], [], [])
PlaygroundPage.current.liveView = dashBoardController
