import UIKit
import PlaygroundSupport

let dashBoardController: DashBoardViewController = DashBoardViewController("3-5", [.Display], [], [])
PlaygroundPage.current.liveView = dashBoardController
